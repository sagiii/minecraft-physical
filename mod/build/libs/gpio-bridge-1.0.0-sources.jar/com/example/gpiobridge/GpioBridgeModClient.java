package com.example.gpiobridge;

import com.example.gpiobridge.screen.ChannelScreen;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_3929;

public class GpioBridgeModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        class_3929.method_17542(ModScreenHandlers.CHANNEL_SCREEN, ChannelScreen::new);
    }
}

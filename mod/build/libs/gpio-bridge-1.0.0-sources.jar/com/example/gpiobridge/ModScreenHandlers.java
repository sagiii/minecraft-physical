package com.example.gpiobridge;

import com.example.gpiobridge.screen.ChannelScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public class ModScreenHandlers {

    public static class_3917<ChannelScreenHandler> CHANNEL_SCREEN;

    public static void initialize() {
        CHANNEL_SCREEN = class_2378.method_10230(
                class_7923.field_41187,
                class_2960.method_60655("gpio_bridge", "channel_screen"),
                new ExtendedScreenHandlerType<>(
                        (syncId, inv, pos) -> new ChannelScreenHandler(syncId, inv, pos),
                        class_2338.field_48404
                )
        );
    }
}

package com.example.gpiobridge.screen;

import com.example.gpiobridge.ModScreenHandlers;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3913;
import net.minecraft.class_3919;

public class ChannelScreenHandler extends class_1703 {

    public final class_2338 blockPos;
    private final class_3913 delegate;

    /** Server-side constructor — called from ChannelBlockEntity.createMenu(). */
    public ChannelScreenHandler(int syncId, class_1661 inv,
                                 class_3913 delegate, class_2338 pos) {
        super(ModScreenHandlers.CHANNEL_SCREEN, syncId);
        this.blockPos = pos;
        this.delegate = delegate;
        method_17360(delegate); // syncs channel value to client automatically
    }

    /** Client-side constructor — called by ExtendedScreenHandlerType factory. */
    public ChannelScreenHandler(int syncId, class_1661 inv, class_2338 pos) {
        this(syncId, inv, new class_3919(1), pos);
    }

    public int getChannel() { return delegate.method_17390(0); }

    @Override
    public boolean method_7597(class_1657 player) { return true; }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) { return class_1799.field_8037; }
}

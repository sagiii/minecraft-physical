package com.example.gpiobridge.screen;

import com.example.gpiobridge.network.SetChannelPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_465;

/**
 * Simple GUI for setting the channel number on a Channel IN / OUT block.
 * Sends a SetChannelPayload packet to the server when the player confirms.
 */
public class ChannelScreen extends class_465<ChannelScreenHandler> {

    private class_342 channelField;
    private static final int BG_W = 200;
    private static final int BG_H = 90;

    public ChannelScreen(ChannelScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        field_2792  = BG_W;
        field_2779 = BG_H;
        field_25270 = BG_H + 4; // hide vanilla inventory label
    }

    @Override
    protected void method_25426() {
        super.method_25426();

        channelField = new class_342(
                field_22793,
                field_2776 + 10, field_2800 + 38,
                100, 20,
                class_2561.method_43471("gui.gpio_bridge.channel_label")
        );
        channelField.method_1880(2);
        channelField.method_1852(String.valueOf(field_2797.getChannel() == 0 ? 1 : field_2797.getChannel()));
        channelField.method_25365(true);
        method_37063(channelField);

        method_37063(class_4185.method_46430(class_2561.method_43471("gui.done"), btn -> confirm())
                .method_46434(field_2776 + 120, field_2800 + 38, 70, 20)
                .method_46431());
    }

    private void confirm() {
        int ch = 0;
        try {
            ch = Integer.parseInt(channelField.method_1882().trim());
        } catch (NumberFormatException ignored) {}
        ch = Math.max(1, Math.min(99, ch));
        ClientPlayNetworking.send(new SetChannelPayload(field_2797.blockPos, ch));
        method_25419();
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        // Enter key confirms
        if (keyCode == 257 /* GLFW_KEY_ENTER */ || keyCode == 335 /* GLFW_KEY_KP_ENTER */) {
            confirm();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        // Dark semi-transparent panel
        context.method_25294(field_2776, field_2800, field_2776 + BG_W, field_2800 + BG_H, 0xD0101010);
        context.method_25294(field_2776 + 1, field_2800 + 1, field_2776 + BG_W - 1, field_2800 + BG_H - 1, 0xC0202020);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        // Title
        context.method_27535(field_22793,
                method_25440(), field_2776 + 10, field_2800 + 10, 0xFFFFFF);
        // Label
        context.method_27535(field_22793,
                class_2561.method_43471("gui.gpio_bridge.channel_label"),
                field_2776 + 10, field_2800 + 28, 0xAAAAAA);
    }

    // Hide vanilla slot rendering — this screen has no inventory slots
    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {}
}

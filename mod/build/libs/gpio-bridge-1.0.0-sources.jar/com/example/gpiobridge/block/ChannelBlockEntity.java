package com.example.gpiobridge.block;

import com.example.gpiobridge.ModBlockEntityTypes;
import com.example.gpiobridge.network.MqttBridgeClient;
import com.example.gpiobridge.screen.ChannelScreenHandler;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3913;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

public class ChannelBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory<class_2338> {

    private int channel = 0; // 0 = unset, 1-99 = active

    private final class_3913 propertyDelegate = new class_3913() {
        @Override public int method_17390(int index)             { return index == 0 ? channel : 0; }
        @Override public void method_17391(int index, int value) { if (index == 0) applyChannel(value); }
        @Override public int method_17389()                     { return 1; }
    };

    public ChannelBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntityTypes.CHANNEL_BLOCK_ENTITY, pos, state);
    }

    // ----- channel management -----

    public int getChannel() { return channel; }

    /** Called both from screen (via PropertyDelegate) and from server packet handler. */
    public void setChannel(int newChannel) {
        applyChannel(newChannel);
    }

    private void applyChannel(int value) {
        int clamped = Math.max(0, Math.min(99, value));
        if (clamped == channel) return;
        int old = channel;
        channel = clamped;
        if (field_11863 != null && !field_11863.field_9236) {
            if (old > 0) MqttBridgeClient.INSTANCE.unregister(old, field_11867);
            registerWithMqtt();
            method_5431();
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    @Override
    public void method_31662(class_1937 world) {
        super.method_31662(world);
        if (!world.field_9236 && channel > 0) registerWithMqtt();
    }

    @Override
    public void method_11012() {
        super.method_11012();
        if (channel > 0) MqttBridgeClient.INSTANCE.unregister(channel, field_11867);
    }

    private void registerWithMqtt() {
        if (channel <= 0) return;
        class_2248 block = method_11010().method_26204();
        if (block instanceof ChannelInBlock) {
            MqttBridgeClient.INSTANCE.registerIn(channel, field_11867);
        } else if (block instanceof ChannelOutBlock) {
            MqttBridgeClient.INSTANCE.registerOut(channel, field_11867);
        }
    }

    // ----- called by MqttBridgeClient (server thread) -----

    public void updateFromMqtt(boolean value, class_1937 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        if (!(state.method_26204() instanceof ChannelInBlock)) return;
        if (state.method_11654(ChannelInBlock.POWERED) != value) {
            world.method_8501(pos, state.method_11657(ChannelInBlock.POWERED, value));
        }
    }

    // ----- called by ChannelOutBlock when redstone changes -----

    public void sendToMqtt(boolean powered) {
        if (channel <= 0) return;
        MqttBridgeClient.INSTANCE.publish(channel, powered);
    }

    // ----- persistence -----

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10569("channel", channel);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        channel = nbt.method_10550("channel");
    }

    @Override
    public @Nullable class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        return method_38244(registries);
    }

    // ----- screen factory -----

    @Override
    public class_2338 getScreenOpeningData(class_3222 player) { return field_11867; }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43471(method_11010().method_26204().method_63499());
    }

    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new ChannelScreenHandler(syncId, playerInventory, propertyDelegate, field_11867);
    }
}

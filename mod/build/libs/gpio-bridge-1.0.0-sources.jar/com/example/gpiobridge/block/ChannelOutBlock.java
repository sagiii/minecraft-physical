package com.example.gpiobridge.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3965;
import net.minecraft.class_9904;
import org.jetbrains.annotations.Nullable;

/**
 * Channel OUT block: Minecraft → M5Stack
 *
 * When redstone power is applied/removed, publishes to the configured MQTT channel.
 * Right-click to configure the channel number (1-99).
 * Lights up (luminance 15) when powered.
 */
public class ChannelOutBlock extends class_2237 {

    public static final MapCodec<ChannelOutBlock> CODEC = method_54094(ChannelOutBlock::new);
    public static final class_2746 POWERED = class_2741.field_12484;

    public ChannelOutBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(POWERED, false));
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() { return field_46280; }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(POWERED);
    }

    // ----- redstone input detection -----

    @Override
    protected void method_9612(class_2680 state, class_1937 world, class_2338 pos,
                                   class_2248 sourceBlock, @Nullable class_9904 wireOrientation,
                                   boolean notify) {
        if (world.field_9236) return;
        boolean powered = world.method_49803(pos);
        if (powered != state.method_11654(POWERED)) {
            world.method_8652(pos, state.method_11657(POWERED, powered), class_2248.field_31036);
            if (world.method_8321(pos) instanceof ChannelBlockEntity be) {
                be.sendToMqtt(powered);
            }
        }
    }

    // ----- right-click: open channel GUI -----

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos,
                                  class_1657 player, class_3965 hit) {
        if (!world.field_9236) {
            if (world.method_8321(pos) instanceof ChannelBlockEntity be) {
                player.method_17355(be);
            }
        }
        return class_1269.field_5812;
    }

    // ----- block entity -----

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ChannelBlockEntity(pos, state);
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }
}

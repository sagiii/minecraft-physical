package com.example.gpiobridge;

import com.example.gpiobridge.block.ChannelBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntityTypes {

    public static class_2591<ChannelBlockEntity> CHANNEL_BLOCK_ENTITY;

    public static void initialize() {
        CHANNEL_BLOCK_ENTITY = class_2378.method_10230(
                class_7923.field_41181,
                class_2960.method_60655("gpio_bridge", "channel_block_entity"),
                FabricBlockEntityTypeBuilder.create(ChannelBlockEntity::new,
                        ModBlocks.CHANNEL_IN,
                        ModBlocks.CHANNEL_OUT
                ).build()
        );
    }
}

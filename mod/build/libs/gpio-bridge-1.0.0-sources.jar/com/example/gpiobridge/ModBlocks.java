package com.example.gpiobridge;

import com.example.gpiobridge.block.ChannelInBlock;
import com.example.gpiobridge.block.ChannelOutBlock;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class ModBlocks {

    public static final class_2248 CHANNEL_IN = register("channel_in",
            new ChannelInBlock(class_4970.class_2251.method_9637()
                    .method_9632(1.5f)
                    .method_9626(class_2498.field_11544)
                    .method_31710(class_3620.field_16024)
                    .method_9631(state -> state.method_11654(ChannelInBlock.POWERED) ? 15 : 0)
                    .method_22488()));

    public static final class_2248 CHANNEL_OUT = register("channel_out",
            new ChannelOutBlock(class_4970.class_2251.method_9637()
                    .method_9632(1.5f)
                    .method_9626(class_2498.field_11544)
                    .method_31710(class_3620.field_15987)
                    .method_9631(state -> state.method_11654(ChannelOutBlock.POWERED) ? 15 : 0)
                    .method_22488()));

    private static class_2248 register(String name, class_2248 block) {
        class_2960 id = class_2960.method_60655("gpio_bridge", name);
        class_2378.method_10230(class_7923.field_41175, id, block);
        class_2378.method_10230(class_7923.field_41178,  id, new class_1747(block, new class_1792.class_1793()));
        return block;
    }

    public static void initialize() {
        // Add to the Redstone Blocks tab for discoverability
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40198).register(entries -> {
            entries.method_45421(CHANNEL_IN);
            entries.method_45421(CHANNEL_OUT);
        });
    }
}

package com.example.gpiobridge.network;

import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record SetChannelPayload(class_2338 pos, int channel) implements class_8710 {

    public static final class_9154<SetChannelPayload> ID =
            new class_9154<>(class_2960.method_60655("gpio_bridge", "set_channel"));

    public static final class_9139<class_2540, SetChannelPayload> CODEC =
            class_9139.method_56435(
                    class_2338.field_48404,    SetChannelPayload::pos,
                    class_9135.field_48550,     SetChannelPayload::channel,
                    SetChannelPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() { return ID; }
}
